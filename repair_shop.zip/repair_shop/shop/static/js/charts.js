// Лёгкие SVG-графики без внешних библиотек.
const Charts = (function () {
  const NS = 'http://www.w3.org/2000/svg';
  const W = 560, H = 260, P = { l: 44, r: 12, t: 12, b: 34 };
  const el = (n, a = {}, t) => { const e = document.createElementNS(NS, n);
    for (const k in a) e.setAttribute(k, a[k]); if (t != null) e.textContent = t; return e; };
  const esc = s => String(s);
  const svg = id => { const box = document.getElementById(id); box.innerHTML = '';
    const s = el('svg', { viewBox: `0 0 ${W} ${H}`, preserveAspectRatio: 'xMidYMid meet' }); box.appendChild(s); return s; };
  const nice = m => { if (m <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(m)));
    const f = m / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p; };
  const fmt = n => n >= 1000 ? (n / 1000).toFixed(n % 1000 ? 1 : 0) + 'k' : String(n);

  function axes(s, labels, max) {
    const top = nice(max), ih = H - P.t - P.b;
    for (let i = 0; i <= 4; i++) {
      const y = P.t + ih - ih * i / 4;
      s.appendChild(el('line', { x1: P.l, x2: W - P.r, y1: y, y2: y, stroke: '#e2e8f0' }));
      s.appendChild(el('text', { x: P.l - 6, y: y + 4, 'text-anchor': 'end' }, fmt(top * i / 4)));
    }
    const step = Math.ceil(labels.length / 8), iw = W - P.l - P.r;
    labels.forEach((l, i) => { if (i % step === 0)
      s.appendChild(el('text', { x: P.l + iw * (i + .5) / labels.length, y: H - 12, 'text-anchor': 'middle' }, l)); });
    return top;
  }

  function bars(id, labels, values, color, f) {
    const s = svg(id), top = axes(s, labels, Math.max(...values, 1));
    const iw = W - P.l - P.r, ih = H - P.t - P.b, bw = iw / labels.length;
    values.forEach((v, i) => {
      const h = ih * v / top;
      const r = el('rect', { x: P.l + bw * i + bw * .15, y: P.t + ih - h, width: bw * .7, height: Math.max(h, 0), rx: 3, fill: color });
      r.appendChild(el('title', {}, labels[i] + ': ' + (f ? f(v) : v)));
      s.appendChild(r);
    });
  }

  function line(id, labels, values, color) {
    const s = svg(id), top = axes(s, labels, Math.max(...values, 1));
    const iw = W - P.l - P.r, ih = H - P.t - P.b;
    const pts = values.map((v, i) => [P.l + iw * (i + .5) / labels.length, P.t + ih - ih * v / top]);
    s.appendChild(el('polyline', { points: pts.map(p => p.join(',')).join(' '), fill: 'none', stroke: color, 'stroke-width': 2.5, 'stroke-linejoin': 'round' }));
    pts.forEach((p, i) => { const c = el('circle', { cx: p[0], cy: p[1], r: 3.5, fill: color });
      c.appendChild(el('title', {}, labels[i] + ': ' + values[i])); s.appendChild(c); });
  }

  function hbars(id, labels, values, color) {
    const s = svg(id), max = Math.max(...values, 1), n = labels.length || 1;
    const lw = 150, ih = H - 16, rh = Math.min(34, ih / n);
    labels.forEach((l, i) => {
      const y = 8 + i * rh, w = (W - lw - 50) * values[i] / max;
      s.appendChild(el('text', { x: lw - 8, y: y + rh / 2 + 3, 'text-anchor': 'end' }, l.length > 24 ? l.slice(0, 23) + '…' : l));
      s.appendChild(el('rect', { x: lw, y: y + 4, width: Math.max(w, 1), height: rh - 10, rx: 3, fill: color }));
      s.appendChild(el('text', { x: lw + w + 6, y: y + rh / 2 + 3 }, values[i]));
    });
  }

  function donut(id, legendId, d) {
    const s = svg(id), total = d.values.reduce((a, b) => a + b, 0) || 1;
    const cx = W / 2, cy = H / 2, R = 100, r = 60; let a0 = -Math.PI / 2;
    d.values.forEach((v, i) => {
      if (!v) return;
      const a1 = a0 + 2 * Math.PI * v / total - (d.values.filter(x => x).length > 1 ? 0.01 : 0);
      const big = a1 - a0 > Math.PI ? 1 : 0, p = (a, rad) => [cx + rad * Math.cos(a), cy + rad * Math.sin(a)];
      const [x0, y0] = p(a0, R), [x1, y1] = p(a1, R), [x2, y2] = p(a1, r), [x3, y3] = p(a0, r);
      const path = el('path', { d: `M${x0},${y0} A${R},${R} 0 ${big} 1 ${x1},${y1} L${x2},${y2} A${r},${r} 0 ${big} 0 ${x3},${y3} Z`, fill: d.colors[i] });
      path.appendChild(el('title', {}, d.labels[i] + ': ' + v)); s.appendChild(path); a0 += 2 * Math.PI * v / total;
    });
    s.appendChild(el('text', { x: cx, y: cy + 6, 'text-anchor': 'middle', style: 'font-size:22px;font-weight:700;fill:#1e293b' }, total));
    const lg = document.getElementById(legendId); lg.innerHTML = '';
    d.labels.forEach((l, i) => { const sp = document.createElement('span');
      sp.innerHTML = `<i style="background:${d.colors[i]}"></i>`; sp.append(l + ' — ' + d.values[i]); lg.appendChild(sp); });
  }
  return { bars, line, hbars, donut };
})();

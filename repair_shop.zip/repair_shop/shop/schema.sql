PRAGMA foreign_keys = ON;

-- Пользователи (клиенты, мастера, администраторы)
CREATE TABLE users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    email         TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT    NOT NULL,
    full_name     TEXT    NOT NULL CHECK (length(full_name) BETWEEN 2 AND 100),
    phone         TEXT,
    role          TEXT    NOT NULL DEFAULT 'client'
                  CHECK (role IN ('client', 'master', 'admin')),
    is_active     INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Справочники
CREATE TABLE device_types (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE fault_types (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE statuses (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    code       TEXT    NOT NULL UNIQUE,
    title      TEXT    NOT NULL,
    sort_order INTEGER NOT NULL UNIQUE,
    color      TEXT    NOT NULL DEFAULT '#64748b'
);

-- Каталог услуг
CREATE TABLE services (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT    NOT NULL CHECK (length(name) BETWEEN 2 AND 120),
    description    TEXT,
    device_type_id INTEGER REFERENCES device_types (id) ON DELETE SET NULL,
    price_from     REAL    NOT NULL CHECK (price_from >= 0),
    price_to       REAL    NOT NULL,
    duration_days  INTEGER NOT NULL DEFAULT 1 CHECK (duration_days >= 1),
    is_active      INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    CHECK (price_to >= price_from)
);

-- Заявки на ремонт
CREATE TABLE orders (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    public_token   TEXT    NOT NULL UNIQUE,
    client_id      INTEGER NOT NULL REFERENCES users (id) ON DELETE RESTRICT,
    master_id      INTEGER REFERENCES users (id) ON DELETE SET NULL,
    device_type_id INTEGER NOT NULL REFERENCES device_types (id) ON DELETE RESTRICT,
    fault_type_id  INTEGER NOT NULL REFERENCES fault_types (id) ON DELETE RESTRICT,
    service_id     INTEGER REFERENCES services (id) ON DELETE SET NULL,
    device_model   TEXT    NOT NULL CHECK (length(device_model) BETWEEN 2 AND 120),
    description    TEXT    NOT NULL CHECK (length(description) BETWEEN 10 AND 2000),
    status_id      INTEGER NOT NULL DEFAULT 1 REFERENCES statuses (id),
    labor_cost     REAL    NOT NULL DEFAULT 0 CHECK (labor_cost >= 0),
    created_at     TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at     TEXT    NOT NULL DEFAULT (datetime('now')),
    closed_at      TEXT
);
CREATE INDEX idx_orders_client ON orders (client_id);
CREATE INDEX idx_orders_master ON orders (master_id);
CREATE INDEX idx_orders_status ON orders (status_id);
CREATE INDEX idx_orders_created ON orders (created_at);

CREATE TABLE order_photos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id    INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    filename    TEXT    NOT NULL UNIQUE,
    uploaded_at TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE order_comments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    user_id    INTEGER NOT NULL REFERENCES users (id) ON DELETE RESTRICT,
    body       TEXT    NOT NULL CHECK (length(body) BETWEEN 1 AND 1000),
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE status_history (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    status_id  INTEGER NOT NULL REFERENCES statuses (id),
    changed_by INTEGER REFERENCES users (id) ON DELETE SET NULL,
    changed_at TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Склад запчастей
CREATE TABLE parts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT    NOT NULL CHECK (length(name) BETWEEN 2 AND 120),
    sku          TEXT    NOT NULL UNIQUE,
    quantity     INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    min_quantity INTEGER NOT NULL DEFAULT 1 CHECK (min_quantity >= 0),
    unit_price   REAL    NOT NULL CHECK (unit_price >= 0)
);

-- Запчасти, использованные в заявке
CREATE TABLE order_parts (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    part_id    INTEGER NOT NULL REFERENCES parts (id) ON DELETE RESTRICT,
    quantity   INTEGER NOT NULL CHECK (quantity > 0),
    unit_price REAL    NOT NULL CHECK (unit_price >= 0)
);
CREATE INDEX idx_order_parts_order ON order_parts (order_id);

-- Уведомления клиентам (дублируются на e-mail, если настроен SMTP)
CREATE TABLE notifications (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    order_id   INTEGER REFERENCES orders (id) ON DELETE CASCADE,
    message    TEXT    NOT NULL,
    is_read    INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0, 1)),
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_notifications_user ON notifications (user_id, is_read);

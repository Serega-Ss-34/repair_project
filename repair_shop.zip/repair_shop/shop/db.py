"""Работа с SQLite: подключение на запрос, параметризованные запросы."""
import os
import sqlite3

from flask import current_app, g

SCHEMA_PATH = os.path.join(os.path.dirname(__file__), "schema.sql")


def get_db():
    if "db" not in g:
        conn = sqlite3.connect(current_app.config["DATABASE"])
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        g.db = conn
    return g.db


def close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def query(sql, args=(), one=False):
    """SELECT. Значения передаются только параметрами (защита от SQL-инъекций)."""
    cur = get_db().execute(sql, args)
    rows = cur.fetchall()
    return (rows[0] if rows else None) if one else rows


def execute(sql, args=()):
    cur = get_db().execute(sql, args)
    return cur


def commit():
    get_db().commit()


def init_db():
    conn = get_db()
    with open(SCHEMA_PATH, encoding="utf-8") as f:
        conn.executescript(f.read())
    conn.executemany(
        "INSERT INTO statuses (code, title, sort_order, color) VALUES (?, ?, ?, ?)",
        [
            ("accepted", "Принята", 1, "#6366f1"),
            ("diagnostics", "В диагностике", 2, "#f59e0b"),
            ("repair", "В ремонте", 3, "#0ea5e9"),
            ("ready", "Готова к выдаче", 4, "#10b981"),
            ("issued", "Выдана", 5, "#64748b"),
        ],
    )
    conn.commit()


def init_app(app):
    app.teardown_appcontext(close_db)

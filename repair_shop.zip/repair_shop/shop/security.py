"""Аутентификация, роли, CSRF, ограничение попыток входа."""
import secrets
import time
from functools import wraps

from flask import abort, flash, g, redirect, request, session, url_for

from . import db

_failed_logins = {}  # ключ -> список меток времени
MAX_FAILS = 5
WINDOW = 300  # секунд


def load_user():
    g.user = None
    uid = session.get("uid")
    if uid:
        user = db.query("SELECT * FROM users WHERE id = ? AND is_active = 1", (uid,), one=True)
        if user is None:
            session.clear()
        g.user = user


def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


def csrf_protect():
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        expected = session.get("_csrf")
        sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token")
        if not expected or not sent or not secrets.compare_digest(expected, sent):
            abort(400, "Неверный CSRF-токен. Обновите страницу и повторите.")


def login_required(*roles):
    """Требует вход; если указаны роли — ещё и принадлежность к одной из них."""

    def decorator(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if g.user is None:
                flash("Войдите в систему, чтобы продолжить", "warn")
                return redirect(url_for("auth.login", next=request.path))
            if roles and g.user["role"] not in roles:
                abort(403)
            return view(*args, **kwargs)

        return wrapper

    return decorator


def home_for(user):
    return {
        "client": "orders.cabinet",
        "master": "orders.master_index",
        "admin": "admin.dashboard",
    }[user["role"]]


def too_many_attempts(key):
    now = time.time()
    recent = [t for t in _failed_logins.get(key, []) if now - t < WINDOW]
    _failed_logins[key] = recent
    return len(recent) >= MAX_FAILS


def register_failure(key):
    _failed_logins.setdefault(key, []).append(time.time())


def clear_failures(key):
    _failed_logins.pop(key, None)


def safe_next(target):
    """Разрешаем только относительные пути внутри сайта (защита от open redirect)."""
    if target and target.startswith("/") and not target.startswith("//"):
        return target
    return None

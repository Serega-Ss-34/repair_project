# Ремонтная мастерская — веб-приложение

Приём заявок на ремонт техники, отслеживание статуса, учёт запчастей.
Стек: Python 3.11+, Flask, SQLite, Jinja2, HTML/CSS/JavaScript, reportlab (PDF + QR), Pillow.

## Запуск
```bash
pip install -r requirements.txt
python -m flask --app run seed     # создать БД и демо-данные
python run.py                      # http://127.0.0.1:5000
```
Пустая БД без демо-данных: `python -m flask --app run init-db` (затем создайте администратора вручную или через seed).

## Демо-аккаунты
| Роль | E-mail | Пароль |
|---|---|---|
| Администратор | admin@repair.local | Admin12345 |
| Мастер | ivanov@repair.local | Demo12345 |
| Клиент | client1@mail.ru | Demo12345 |

## Тесты
```bash
python -m unittest discover -s tests -t . -v
```

## Настройки (переменные окружения)
`SECRET_KEY` (обязательно задать в продакшене), `COOKIE_SECURE=1` (при HTTPS),
`SMTP_HOST/SMTP_PORT/SMTP_USER/SMTP_PASSWORD/SMTP_FROM` — отправка e-mail клиентам (без SMTP уведомления видны в кабинете).

## Публикация
```bash
pip install gunicorn
SECRET_KEY=... COOKIE_SECURE=1 gunicorn -w 2 -b 0.0.0.0:8000 run:app
```
За reverse-proxy (nginx) с HTTPS. Каталог `instance/` (БД и загруженные фото) нужно сохранять между перезапусками.

## Структура
- `shop/` — приложение (`auth`, `orders`, `admin`, `public`, `logic`, `pdf`, `seed`, `schema.sql`)
- `docs/` — ER-диаграмма и описание БД (`python tools/gen_er.py` пересоздаёт)
- `tests/` — автотесты

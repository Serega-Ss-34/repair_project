"""Бизнес-логика заявок: статусы, запчасти, уведомления, права доступа."""
import logging
import os
import secrets
import smtplib
import uuid
from email.message import EmailMessage

from flask import abort, current_app, g

from . import db
from .validators import ValidationError

log = logging.getLogger(__name__)

ORDER_SELECT = """
SELECT o.*, s.code AS status_code, s.title AS status_title, s.color AS status_color,
       dt.name AS device_type, ft.name AS fault_type, sv.name AS service_name,
       c.full_name AS client_name, c.email AS client_email, c.phone AS client_phone,
       m.full_name AS master_name,
       COALESCE((SELECT SUM(op.quantity * op.unit_price) FROM order_parts op
                 WHERE op.order_id = o.id), 0) AS parts_cost
FROM orders o
JOIN statuses s      ON s.id = o.status_id
JOIN device_types dt ON dt.id = o.device_type_id
JOIN fault_types ft  ON ft.id = o.fault_type_id
JOIN users c         ON c.id = o.client_id
LEFT JOIN users m    ON m.id = o.master_id
LEFT JOIN services sv ON sv.id = o.service_id
"""


def get_order(order_id):
    return db.query(ORDER_SELECT + " WHERE o.id = ?", (order_id,), one=True)


def can_view(order, user):
    if user is None or order is None:
        return False
    if user["role"] == "admin":
        return True
    if user["role"] == "master":
        return order["master_id"] == user["id"]
    return order["client_id"] == user["id"]


def can_manage(order, user):
    """Менять статус/запчасти может админ или назначенный мастер."""
    if user is None or order is None:
        return False
    return user["role"] == "admin" or (
        user["role"] == "master" and order["master_id"] == user["id"]
    )


def get_order_or_404(order_id, manage=False):
    order = get_order(order_id)
    if order is None:
        abort(404)
    allowed = can_manage(order, g.user) if manage else can_view(order, g.user)
    if not allowed:
        abort(403)
    return order


def order_total(order):
    return round(order["labor_cost"] + order["parts_cost"], 2)


def new_token():
    return secrets.token_urlsafe(16)


# ---------- уведомления ----------
def send_email(to, subject, body):
    host = os.environ.get("SMTP_HOST")
    if not host:
        log.info("E-mail (SMTP не настроен) -> %s: %s", to, subject)
        return False
    try:
        msg = EmailMessage()
        msg["From"] = os.environ.get("SMTP_FROM", "no-reply@repair.local")
        msg["To"] = to
        msg["Subject"] = subject
        msg.set_content(body)
        with smtplib.SMTP(host, int(os.environ.get("SMTP_PORT", "25")), timeout=5) as s:
            if os.environ.get("SMTP_USER"):
                s.starttls()
                s.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
            s.send_message(msg)
        return True
    except Exception:  # почта не должна ломать работу приложения
        log.exception("Не удалось отправить e-mail")
        return False


def notify(user_id, order_id, message):
    db.execute(
        "INSERT INTO notifications (user_id, order_id, message) VALUES (?, ?, ?)",
        (user_id, order_id, message),
    )
    row = db.query("SELECT email FROM users WHERE id = ?", (user_id,), one=True)
    if row:
        send_email(row["email"], f"Заявка №{order_id}", message)


# ---------- статусы ----------
def get_status(code):
    st = db.query("SELECT * FROM statuses WHERE code = ?", (code,), one=True)
    if st is None:
        raise ValidationError("Неизвестный статус")
    return st


def change_status(order, code, user):
    """Меняет статус. Мастер не может менять уже выданную заявку (только админ)."""
    st = get_status(code)
    if st["id"] == order["status_id"]:
        return False
    if order["status_code"] == "issued" and user["role"] != "admin":
        raise ValidationError("Заявка уже выдана, статус может изменить только администратор")
    closed = "datetime('now')" if code == "issued" else "NULL"
    db.execute(
        f"UPDATE orders SET status_id = ?, updated_at = datetime('now'), closed_at = {closed} "
        "WHERE id = ?",
        (st["id"], order["id"]),
    )
    db.execute(
        "INSERT INTO status_history (order_id, status_id, changed_by) VALUES (?, ?, ?)",
        (order["id"], st["id"], user["id"]),
    )
    notify(order["client_id"], order["id"],
           f"Статус вашей заявки №{order['id']} изменён: «{st['title']}»")
    db.commit()
    return True


# ---------- запчасти ----------
def add_part(order, part_id, qty):
    part = db.query("SELECT * FROM parts WHERE id = ?", (part_id,), one=True)
    if part is None:
        raise ValidationError("Запчасть не найдена")
    if order["status_code"] == "issued":
        raise ValidationError("Нельзя менять запчасти в выданной заявке")
    # атомарное списание: условие quantity >= qty исключает уход в минус
    cur = db.execute(
        "UPDATE parts SET quantity = quantity - ? WHERE id = ? AND quantity >= ?",
        (qty, part_id, qty),
    )
    if cur.rowcount == 0:
        raise ValidationError(f"Недостаточно на складе: «{part['name']}» (есть {part['quantity']})")
    db.execute(
        "INSERT INTO order_parts (order_id, part_id, quantity, unit_price) VALUES (?, ?, ?, ?)",
        (order["id"], part_id, qty, part["unit_price"]),
    )
    db.execute("UPDATE orders SET updated_at = datetime('now') WHERE id = ?", (order["id"],))
    db.commit()


def remove_part(order, order_part_id):
    op = db.query("SELECT * FROM order_parts WHERE id = ? AND order_id = ?",
                  (order_part_id, order["id"]), one=True)
    if op is None:
        raise ValidationError("Запись не найдена")
    if order["status_code"] == "issued":
        raise ValidationError("Нельзя менять запчасти в выданной заявке")
    db.execute("UPDATE parts SET quantity = quantity + ? WHERE id = ?", (op["quantity"], op["part_id"]))
    db.execute("DELETE FROM order_parts WHERE id = ?", (op["id"],))
    db.commit()


# ---------- фото ----------
ALLOWED_FORMATS = {"JPEG": "jpg", "PNG": "png", "WEBP": "webp"}
MAX_PHOTO_BYTES = 5 * 1024 * 1024
MAX_PHOTOS = 3


def save_photo(file_storage):
    """Проверяет, что файл — настоящее изображение (по содержимому), и сохраняет его."""
    from PIL import Image

    data = file_storage.read(MAX_PHOTO_BYTES + 1)
    if not data:
        return None
    if len(data) > MAX_PHOTO_BYTES:
        raise ValidationError("Фото больше 5 МБ")
    import io

    try:
        img = Image.open(io.BytesIO(data))
        fmt = img.format
        img.verify()
    except Exception:
        raise ValidationError("Файл не является изображением")
    if fmt not in ALLOWED_FORMATS:
        raise ValidationError("Допустимы форматы JPG, PNG, WEBP")
    name = f"{uuid.uuid4().hex}.{ALLOWED_FORMATS[fmt]}"
    folder = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(folder, exist_ok=True)
    with open(os.path.join(folder, name), "wb") as f:
        f.write(data)
    return name

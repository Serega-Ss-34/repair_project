"""Валидация вводимых данных на сервере."""
import re

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^\+?[0-9\s\-()]{7,20}$")


class ValidationError(ValueError):
    pass


def clean(value):
    return (value or "").strip()


def text(value, label, min_len=1, max_len=255):
    v = clean(value)
    if not (min_len <= len(v) <= max_len):
        raise ValidationError(f"«{label}»: длина от {min_len} до {max_len} символов")
    return v


def email(value):
    v = clean(value).lower()
    if len(v) > 120 or not EMAIL_RE.match(v):
        raise ValidationError("Введите корректный e-mail")
    return v


def phone(value, required=False):
    v = clean(value)
    if not v:
        if required:
            raise ValidationError("Укажите телефон")
        return None
    if not PHONE_RE.match(v):
        raise ValidationError("Телефон: 7–20 символов, цифры, пробелы, +, -, ( )")
    return v


def password(value):
    v = value or ""
    if len(v) < 8 or len(v) > 128:
        raise ValidationError("Пароль: от 8 до 128 символов")
    if not (re.search(r"[A-Za-zА-Яа-яЁё]", v) and re.search(r"\d", v)):
        raise ValidationError("Пароль должен содержать буквы и цифры")
    return v


def integer(value, label, min_v=0, max_v=1_000_000):
    try:
        n = int(clean(str(value)))
    except (TypeError, ValueError):
        raise ValidationError(f"«{label}»: введите целое число")
    if not (min_v <= n <= max_v):
        raise ValidationError(f"«{label}»: значение от {min_v} до {max_v}")
    return n


def money(value, label, min_v=0.0, max_v=10_000_000.0):
    try:
        n = float(clean(str(value)).replace(",", ".").replace(" ", ""))
    except (TypeError, ValueError):
        raise ValidationError(f"«{label}»: введите число")
    if n != n or not (min_v <= n <= max_v):  # n != n — защита от NaN
        raise ValidationError(f"«{label}»: значение от {min_v:g} до {max_v:g}")
    return round(n, 2)


def choice(value, allowed, label):
    if value not in allowed:
        raise ValidationError(f"«{label}»: недопустимое значение")
    return value

"""Генерирует ER-диаграмму (docs/er_diagram.png/svg) и docs/database.md из реальной схемы SQLite."""
import os
import sqlite3
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

DESC = {
    "users": "Пользователи системы: клиенты, мастера и администраторы (роль — поле role).",
    "device_types": "Справочник типов устройств (смартфон, ноутбук, …).",
    "fault_types": "Справочник видов неисправностей (используется в статистике).",
    "statuses": "Справочник статусов заявки с порядком и цветом.",
    "services": "Каталог услуг с ориентировочными ценами (от/до) и сроком.",
    "orders": "Заявки на ремонт: клиент, мастер, устройство, статус, стоимость работ.",
    "order_photos": "Фотографии неисправности, прикреплённые к заявке.",
    "order_comments": "Комментарии клиента, мастера и администратора к заявке.",
    "status_history": "История смены статусов заявки (кто и когда изменил).",
    "parts": "Склад запчастей: остаток, минимальный остаток, цена.",
    "order_parts": "Запчасти, использованные в заявке (цена фиксируется на момент списания).",
    "notifications": "Уведомления клиенту об изменении статуса (дублируются на e-mail).",
}
COLNOTE = {
    ("users", "role"): "client / master / admin", ("users", "password_hash"): "PBKDF2-хеш пароля",
    ("orders", "public_token"): "токен для QR-кода и публичной страницы статуса",
    ("orders", "closed_at"): "дата выдачи; используется для расчёта выручки",
    ("services", "price_from"): "минимальная цена", ("services", "price_to"): "максимальная цена (≥ price_from)",
    ("parts", "quantity"): "текущий остаток (≥ 0)", ("order_parts", "unit_price"): "цена на момент списания",
}
ORDER = ["users", "orders", "statuses", "device_types", "fault_types", "services", "order_photos",
         "order_comments", "status_history", "parts", "order_parts", "notifications"]


def load():
    import tempfile
    from shop import create_app, db
    tmp = tempfile.mkdtemp()
    app = create_app({"DATABASE": os.path.join(tmp, "er.db"), "UPLOAD_FOLDER": tmp})
    with app.app_context():
        db.init_db()
    con = sqlite3.connect(os.path.join(tmp, "er.db"))
    schema = {}
    for t in ORDER:
        cols = con.execute(f"PRAGMA table_info({t})").fetchall()
        fks = {r[3]: (r[2], r[4], r[6]) for r in con.execute(f"PRAGMA foreign_key_list({t})")}
        uniq = set()
        for idx in con.execute(f"PRAGMA index_list({t})"):
            if idx[2]:
                info = con.execute(f"PRAGMA index_info({idx[1]})").fetchall()
                if len(info) == 1:
                    uniq.add(info[0][2])
        ddl = con.execute("SELECT sql FROM sqlite_master WHERE name=?", (t,)).fetchone()[0]
        schema[t] = dict(cols=cols, fks=fks, uniq=uniq, ddl=ddl)
    return schema


def dot(schema):
    lines = ['digraph ER {', 'graph [rankdir=LR, nodesep=0.5, ranksep=1.6, splines=true, overlap=false, fontname="DejaVu Sans", bgcolor="white", pad=0.3];',
             'node [shape=plaintext, fontname="DejaVu Sans", fontsize=11];',
             'edge [fontname="DejaVu Sans", fontsize=9, color="#475569", arrowhead=crow, arrowtail=tee, dir=both];']
    for t, s in schema.items():
        rows = [f'<TR><TD COLSPAN="3" BGCOLOR="#0f766e"><FONT COLOR="white"><B>{t}</B></FONT></TD></TR>']
        for cid, name, typ, notnull, dflt, pk in s["cols"]:
            tag = "PK" if pk else ("FK" if name in s["fks"] else "")
            tagcell = f'<FONT COLOR="#0f766e"><B>{tag}</B></FONT>' if tag else " "
            bold = f"<B>{name}</B>" if pk else name
            color = "#fef9c3" if pk else ("#e0f2fe" if tag == "FK" else "white")
            rows.append(f'<TR><TD ALIGN="LEFT" BGCOLOR="{color}" PORT="{name}">{bold}</TD>'
                        f'<TD ALIGN="LEFT" BGCOLOR="{color}"><FONT COLOR="#64748b">{typ}</FONT></TD>'
                        f'<TD BGCOLOR="{color}">{tagcell}</TD></TR>')
        lines.append(f'{t} [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="4" COLOR="#94a3b8">{"".join(rows)}</TABLE>>];')
    for t, s in schema.items():
        for col, (ref, refcol, ondel) in s["fks"].items():
            lines.append(f'{t} -> {ref} [arrowhead=tee, arrowtail=crow, taillabel="N", headlabel="1", label="{col}"];')
    lines.append("}")
    return "\n".join(lines)


def markdown(schema):
    out = ["# Описание базы данных\n",
           "СУБД: **SQLite** (файл `instance/repair.db`). Схема — в `shop/schema.sql`. Нормализация: 3НФ.\n",
           "![ER-диаграмма](er_diagram.png)\n",
           "## Связи между таблицами\n"]
    for t, s in schema.items():
        for col, (ref, refcol, ondel) in s["fks"].items():
            out.append(f"- `{ref}` 1 — N `{t}` (`{t}.{col}` → `{ref}.{refcol}`, ON DELETE {ondel})")
    out.append("")
    for t, s in schema.items():
        out += [f"## {t}\n", DESC[t] + "\n", "| Поле | Тип | Ограничения | Примечание |", "|---|---|---|---|"]
        for cid, name, typ, notnull, dflt, pk in s["cols"]:
            c = []
            if pk: c.append("PRIMARY KEY")
            if name in s["fks"]: c.append(f"FK → {s['fks'][name][0]}")
            if name in s["uniq"]: c.append("UNIQUE")
            if notnull and not pk: c.append("NOT NULL")
            if dflt is not None: c.append(f"DEFAULT {dflt}")
            out.append(f"| {name} | {typ} | {', '.join(c)} | {COLNOTE.get((t, name), '')} |")
        out.append("")
    return "\n".join(out)


if __name__ == "__main__":
    sc = load()
    docs = os.path.join(ROOT, "docs")
    os.makedirs(docs, exist_ok=True)
    open(os.path.join(docs, "er_diagram.dot"), "w", encoding="utf-8").write(dot(sc))
    for fmt in ("png", "svg"):
        args = ["dot", f"-T{fmt}", os.path.join(docs, "er_diagram.dot"), "-o", os.path.join(docs, f"er_diagram.{fmt}")]
        if fmt == "png":
            args.insert(1, "-Gdpi=130")
        subprocess.run(args, check=True)
    open(os.path.join(docs, "database.md"), "w", encoding="utf-8").write(markdown(sc))
    print("OK")

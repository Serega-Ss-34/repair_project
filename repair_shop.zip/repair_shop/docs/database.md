# Описание базы данных

СУБД: **SQLite** (файл `instance/repair.db`). Схема — в `shop/schema.sql`. Нормализация: 3НФ.

![ER-диаграмма](er_diagram.png)

## Связи между таблицами

- `statuses` 1 — N `orders` (`orders.status_id` → `statuses.id`, ON DELETE NO ACTION)
- `services` 1 — N `orders` (`orders.service_id` → `services.id`, ON DELETE SET NULL)
- `fault_types` 1 — N `orders` (`orders.fault_type_id` → `fault_types.id`, ON DELETE RESTRICT)
- `device_types` 1 — N `orders` (`orders.device_type_id` → `device_types.id`, ON DELETE RESTRICT)
- `users` 1 — N `orders` (`orders.master_id` → `users.id`, ON DELETE SET NULL)
- `users` 1 — N `orders` (`orders.client_id` → `users.id`, ON DELETE RESTRICT)
- `device_types` 1 — N `services` (`services.device_type_id` → `device_types.id`, ON DELETE SET NULL)
- `orders` 1 — N `order_photos` (`order_photos.order_id` → `orders.id`, ON DELETE CASCADE)
- `users` 1 — N `order_comments` (`order_comments.user_id` → `users.id`, ON DELETE RESTRICT)
- `orders` 1 — N `order_comments` (`order_comments.order_id` → `orders.id`, ON DELETE CASCADE)
- `users` 1 — N `status_history` (`status_history.changed_by` → `users.id`, ON DELETE SET NULL)
- `statuses` 1 — N `status_history` (`status_history.status_id` → `statuses.id`, ON DELETE NO ACTION)
- `orders` 1 — N `status_history` (`status_history.order_id` → `orders.id`, ON DELETE CASCADE)
- `parts` 1 — N `order_parts` (`order_parts.part_id` → `parts.id`, ON DELETE RESTRICT)
- `orders` 1 — N `order_parts` (`order_parts.order_id` → `orders.id`, ON DELETE CASCADE)
- `orders` 1 — N `notifications` (`notifications.order_id` → `orders.id`, ON DELETE CASCADE)
- `users` 1 — N `notifications` (`notifications.user_id` → `users.id`, ON DELETE CASCADE)

## users

Пользователи системы: клиенты, мастера и администраторы (роль — поле role).

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| email | TEXT | UNIQUE, NOT NULL |  |
| password_hash | TEXT | NOT NULL | PBKDF2-хеш пароля |
| full_name | TEXT | NOT NULL |  |
| phone | TEXT |  |  |
| role | TEXT | NOT NULL, DEFAULT 'client' | client / master / admin |
| is_active | INTEGER | NOT NULL, DEFAULT 1 |  |
| created_at | TEXT | NOT NULL, DEFAULT datetime('now') |  |

## orders

Заявки на ремонт: клиент, мастер, устройство, статус, стоимость работ.

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| public_token | TEXT | UNIQUE, NOT NULL | токен для QR-кода и публичной страницы статуса |
| client_id | INTEGER | FK → users, NOT NULL |  |
| master_id | INTEGER | FK → users |  |
| device_type_id | INTEGER | FK → device_types, NOT NULL |  |
| fault_type_id | INTEGER | FK → fault_types, NOT NULL |  |
| service_id | INTEGER | FK → services |  |
| device_model | TEXT | NOT NULL |  |
| description | TEXT | NOT NULL |  |
| status_id | INTEGER | FK → statuses, NOT NULL, DEFAULT 1 |  |
| labor_cost | REAL | NOT NULL, DEFAULT 0 |  |
| created_at | TEXT | NOT NULL, DEFAULT datetime('now') |  |
| updated_at | TEXT | NOT NULL, DEFAULT datetime('now') |  |
| closed_at | TEXT |  | дата выдачи; используется для расчёта выручки |

## statuses

Справочник статусов заявки с порядком и цветом.

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| code | TEXT | UNIQUE, NOT NULL |  |
| title | TEXT | NOT NULL |  |
| sort_order | INTEGER | UNIQUE, NOT NULL |  |
| color | TEXT | NOT NULL, DEFAULT '#64748b' |  |

## device_types

Справочник типов устройств (смартфон, ноутбук, …).

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| name | TEXT | UNIQUE, NOT NULL |  |

## fault_types

Справочник видов неисправностей (используется в статистике).

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| name | TEXT | UNIQUE, NOT NULL |  |

## services

Каталог услуг с ориентировочными ценами (от/до) и сроком.

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| name | TEXT | NOT NULL |  |
| description | TEXT |  |  |
| device_type_id | INTEGER | FK → device_types |  |
| price_from | REAL | NOT NULL | минимальная цена |
| price_to | REAL | NOT NULL | максимальная цена (≥ price_from) |
| duration_days | INTEGER | NOT NULL, DEFAULT 1 |  |
| is_active | INTEGER | NOT NULL, DEFAULT 1 |  |

## order_photos

Фотографии неисправности, прикреплённые к заявке.

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| order_id | INTEGER | FK → orders, NOT NULL |  |
| filename | TEXT | UNIQUE, NOT NULL |  |
| uploaded_at | TEXT | NOT NULL, DEFAULT datetime('now') |  |

## order_comments

Комментарии клиента, мастера и администратора к заявке.

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| order_id | INTEGER | FK → orders, NOT NULL |  |
| user_id | INTEGER | FK → users, NOT NULL |  |
| body | TEXT | NOT NULL |  |
| created_at | TEXT | NOT NULL, DEFAULT datetime('now') |  |

## status_history

История смены статусов заявки (кто и когда изменил).

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| order_id | INTEGER | FK → orders, NOT NULL |  |
| status_id | INTEGER | FK → statuses, NOT NULL |  |
| changed_by | INTEGER | FK → users |  |
| changed_at | TEXT | NOT NULL, DEFAULT datetime('now') |  |

## parts

Склад запчастей: остаток, минимальный остаток, цена.

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| name | TEXT | NOT NULL |  |
| sku | TEXT | UNIQUE, NOT NULL |  |
| quantity | INTEGER | NOT NULL, DEFAULT 0 | текущий остаток (≥ 0) |
| min_quantity | INTEGER | NOT NULL, DEFAULT 1 |  |
| unit_price | REAL | NOT NULL |  |

## order_parts

Запчасти, использованные в заявке (цена фиксируется на момент списания).

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| order_id | INTEGER | FK → orders, NOT NULL |  |
| part_id | INTEGER | FK → parts, NOT NULL |  |
| quantity | INTEGER | NOT NULL |  |
| unit_price | REAL | NOT NULL | цена на момент списания |

## notifications

Уведомления клиенту об изменении статуса (дублируются на e-mail).

| Поле | Тип | Ограничения | Примечание |
|---|---|---|---|
| id | INTEGER | PRIMARY KEY |  |
| user_id | INTEGER | FK → users, NOT NULL |  |
| order_id | INTEGER | FK → orders |  |
| message | TEXT | NOT NULL |  |
| is_read | INTEGER | NOT NULL, DEFAULT 0 |  |
| created_at | TEXT | NOT NULL, DEFAULT datetime('now') |  |

// Канбан-доска: drag-and-drop на стандартном HTML5 API, статус меняется через fetch.
(function () {
  const board = document.querySelector('.kanban');
  if (!board) return;
  const csrf = board.dataset.csrf;
  const tpl = board.dataset.urlTemplate;      // .../api/orders/0/status
  const msg = document.getElementById('kanban-msg');
  let dragged = null, origin = null;

  const recount = () => board.querySelectorAll('.column').forEach(c =>
    c.querySelector('.count').textContent = c.querySelectorAll('.kcard').length);

  board.addEventListener('dragstart', e => {
    const card = e.target.closest('.kcard');
    if (!card) return;
    dragged = card; origin = card.parentElement;
    card.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', card.dataset.id);
  });
  board.addEventListener('dragend', () => {
    if (dragged) dragged.classList.remove('dragging');
    board.querySelectorAll('.column').forEach(c => c.classList.remove('over'));
    dragged = null;
  });
  board.querySelectorAll('.column').forEach(col => {
    col.addEventListener('dragover', e => { e.preventDefault(); col.classList.add('over'); });
    col.addEventListener('dragleave', () => col.classList.remove('over'));
    col.addEventListener('drop', async e => {
      e.preventDefault();
      col.classList.remove('over');
      if (!dragged || col === origin) return;
      const card = dragged, from = origin;
      col.appendChild(card); recount();
      try {
        const r = await fetch(tpl.replace('/0/', '/' + card.dataset.id + '/'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
          body: JSON.stringify({ status: col.dataset.status }),
        });
        const d = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(d.error || 'Ошибка сервера');
        msg.style.display = 'none';
      } catch (err) {
        from.appendChild(card); recount();   // откат при ошибке
        msg.textContent = err.message; msg.style.display = 'block';
      }
    });
  });
})();

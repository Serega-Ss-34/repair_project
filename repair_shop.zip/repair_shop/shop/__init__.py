import os
from datetime import datetime

from flask import Flask, g, render_template

from . import db as dbm
from . import security

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def create_app(config=None):
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-secret-change-me"),
        DATABASE=os.path.join(BASE_DIR, "instance", "repair.db"),
        UPLOAD_FOLDER=os.path.join(BASE_DIR, "instance", "uploads"),
        MAX_CONTENT_LENGTH=20 * 1024 * 1024,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE") == "1",
    )
    if config:
        app.config.update(config)
    os.makedirs(os.path.dirname(app.config["DATABASE"]), exist_ok=True)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    dbm.init_app(app)

    from . import admin, auth, orders, public

    for bp in (public.bp, auth.bp, orders.bp, admin.bp):
        app.register_blueprint(bp)

    app.before_request(security.load_user)
    app.before_request(security.csrf_protect)

    @app.after_request
    def headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        return resp

    @app.context_processor
    def inject():
        unread = 0
        if g.get("user") and g.user["role"] == "client":
            unread = dbm.query(
                "SELECT COUNT(*) c FROM notifications WHERE user_id = ? AND is_read = 0",
                (g.user["id"],), one=True)["c"]
        return {"current_user": g.get("user"), "csrf_token": security.csrf_token,
                "unread_count": unread}

    @app.template_filter("money")
    def money(v):
        v = float(v or 0)
        s = f"{v:,.2f}".replace(",", " ").replace(".", ",")
        if s.endswith(",00"):
            s = s[:-3]
        return f"{s} ₽"

    @app.template_filter("dt")
    def fmt_dt(v):
        if not v:
            return "—"
        try:
            return datetime.strptime(v, "%Y-%m-%d %H:%M:%S").strftime("%d.%m.%Y %H:%M")
        except ValueError:
            return v

    for code, title, text in (
        (400, "Некорректный запрос", "Запрос не прошёл проверку. Обновите страницу и повторите."),
        (403, "Доступ запрещён", "У вас нет прав для просмотра этой страницы."),
        (404, "Страница не найдена", "Такой страницы или заявки не существует."),
        (413, "Файл слишком большой", "Суммарный размер загружаемых файлов превышает лимит."),
    ):
        app.register_error_handler(
            code, lambda e, c=code, t=title, x=text: (render_template("error.html", code=c, title=t, text=x), c))

    @app.cli.command("init-db")
    def init_db_cmd():
        """Создать пустую БД."""
        path = app.config["DATABASE"]
        if os.path.exists(path):
            os.remove(path)
        dbm.init_db()
        print("БД создана:", path)

    @app.cli.command("seed")
    def seed_cmd():
        """Создать БД и заполнить демонстрационными данными."""
        from .seed import seed

        if os.path.exists(app.config["DATABASE"]):
            os.remove(app.config["DATABASE"])
        seed()
        print("Демо-данные загружены")

    return app

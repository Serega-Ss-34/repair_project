from flask import Blueprint, abort, render_template, request

from . import db

bp = Blueprint("public", __name__)


@bp.route("/")
def index():
    services = db.query(
        "SELECT s.*, dt.name AS device_type FROM services s "
        "LEFT JOIN device_types dt ON dt.id = s.device_type_id "
        "WHERE s.is_active = 1 ORDER BY s.price_from LIMIT 6")
    return render_template("index.html", services=services)


@bp.route("/services")
def services():
    q = (request.args.get("q") or "").strip()[:60]
    dev = request.args.get("device", type=int)
    sql = ("SELECT s.*, dt.name AS device_type FROM services s "
           "LEFT JOIN device_types dt ON dt.id = s.device_type_id WHERE s.is_active = 1")
    args = []
    if q:
        sql += " AND (s.name LIKE ? OR s.description LIKE ?)"
        args += [f"%{q}%", f"%{q}%"]
    if dev:
        sql += " AND s.device_type_id = ?"
        args.append(dev)
    sql += " ORDER BY dt.name, s.price_from"
    return render_template(
        "services.html", services=db.query(sql, args), q=q, dev=dev,
        device_types=db.query("SELECT * FROM device_types ORDER BY name"))


@bp.route("/track/<token>")
def track(token):
    """Публичная страница статуса по QR-коду: без персональных данных."""
    order = db.query(
        "SELECT o.id, o.device_model, o.created_at, o.updated_at, s.title AS status_title, "
        "s.sort_order, dt.name AS device_type FROM orders o "
        "JOIN statuses s ON s.id = o.status_id "
        "JOIN device_types dt ON dt.id = o.device_type_id WHERE o.public_token = ?",
        (token,), one=True)
    if order is None:
        abort(404)
    statuses = db.query("SELECT * FROM statuses ORDER BY sort_order")
    history = db.query(
        "SELECT sh.changed_at, s.title FROM status_history sh JOIN statuses s ON s.id = sh.status_id "
        "WHERE sh.order_id = ? ORDER BY sh.id", (order["id"],))
    return render_template("track.html", order=order, statuses=statuses, history=history)

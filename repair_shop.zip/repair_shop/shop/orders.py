"""Заявки: кабинет клиента, рабочее место мастера, карточка заявки, PDF-квитанция."""
import os

from flask import (Blueprint, abort, current_app, flash, g, redirect, render_template,
                   request, send_from_directory, url_for)

from . import db, logic, security, validators as v
from .pdf import build_receipt
from flask import Response

bp = Blueprint("orders", __name__)


def _back(order_id):
    return redirect(url_for("orders.detail", order_id=order_id))


# ---------- клиент ----------
@bp.route("/cabinet")
@security.login_required("client")
def cabinet():
    rows = db.query(logic.ORDER_SELECT + " WHERE o.client_id = ? ORDER BY o.id DESC", (g.user["id"],))
    return render_template("orders/cabinet.html", orders=rows)


@bp.route("/orders/new", methods=["GET", "POST"])
@security.login_required("client")
def new():
    devices = db.query("SELECT * FROM device_types ORDER BY name")
    faults = db.query("SELECT * FROM fault_types ORDER BY id")
    services = db.query("SELECT id, name FROM services WHERE is_active = 1 ORDER BY name")
    if request.method == "POST":
        f = request.form
        try:
            device_id = v.integer(f.get("device_type_id"), "Тип устройства", 1)
            fault_id = v.integer(f.get("fault_type_id"), "Тип неисправности", 1)
            if not db.query("SELECT 1 FROM device_types WHERE id = ?", (device_id,), one=True):
                raise v.ValidationError("Выберите тип устройства")
            if not db.query("SELECT 1 FROM fault_types WHERE id = ?", (fault_id,), one=True):
                raise v.ValidationError("Выберите тип неисправности")
            service_id = None
            if f.get("service_id"):
                service_id = v.integer(f.get("service_id"), "Услуга", 1)
                if not db.query("SELECT 1 FROM services WHERE id = ? AND is_active = 1", (service_id,), one=True):
                    raise v.ValidationError("Услуга не найдена")
            model = v.text(f.get("device_model"), "Модель устройства", 2, 120)
            desc = v.text(f.get("description"), "Описание неисправности", 10, 2000)
            files = [p for p in request.files.getlist("photos") if p and p.filename]
            if len(files) > logic.MAX_PHOTOS:
                raise v.ValidationError(f"Можно загрузить не более {logic.MAX_PHOTOS} фото")
            names = [logic.save_photo(p) for p in files]
        except v.ValidationError as e:
            flash(str(e), "error")
            return render_template("orders/new.html", devices=devices, faults=faults,
                                   services=services, form=f), 400
        cur = db.execute(
            "INSERT INTO orders (public_token, client_id, device_type_id, fault_type_id, service_id, "
            "device_model, description) VALUES (?,?,?,?,?,?,?)",
            (logic.new_token(), g.user["id"], device_id, fault_id, service_id, model, desc))
        oid = cur.lastrowid
        for n in filter(None, names):
            db.execute("INSERT INTO order_photos (order_id, filename) VALUES (?, ?)", (oid, n))
        db.execute("INSERT INTO status_history (order_id, status_id, changed_by) VALUES (?, 1, ?)",
                   (oid, g.user["id"]))
        db.commit()
        flash(f"Заявка №{oid} создана", "ok")
        return redirect(url_for("orders.detail", order_id=oid))
    return render_template("orders/new.html", devices=devices, faults=faults, services=services,
                           form={"service_id": request.args.get("service", "")})


@bp.route("/notifications")
@security.login_required("client")
def notifications():
    rows = db.query("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100",
                    (g.user["id"],))
    db.execute("UPDATE notifications SET is_read = 1 WHERE user_id = ?", (g.user["id"],))
    db.commit()
    return render_template("orders/notifications.html", items=rows)


# ---------- мастер ----------
@bp.route("/master")
@security.login_required("master")
def master_index():
    code = request.args.get("status", "")
    sql = logic.ORDER_SELECT + " WHERE o.master_id = ?"
    args = [g.user["id"]]
    if code:
        sql += " AND s.code = ?"
        args.append(code)
    sql += " ORDER BY (s.code = 'issued'), o.updated_at DESC"
    return render_template("orders/master.html", orders=db.query(sql, args), code=code,
                           statuses=db.query("SELECT * FROM statuses ORDER BY sort_order"))


# ---------- карточка заявки ----------
@bp.route("/orders/<int:order_id>")
@security.login_required()
def detail(order_id):
    order = logic.get_order_or_404(order_id)
    ctx = dict(
        order=order,
        total=logic.order_total(order),
        photos=db.query("SELECT * FROM order_photos WHERE order_id = ? ORDER BY id", (order_id,)),
        comments=db.query(
            "SELECT c.*, u.full_name, u.role FROM order_comments c JOIN users u ON u.id = c.user_id "
            "WHERE c.order_id = ? ORDER BY c.id", (order_id,)),
        history=db.query(
            "SELECT sh.changed_at, s.title, s.color FROM status_history sh "
            "JOIN statuses s ON s.id = sh.status_id WHERE sh.order_id = ? ORDER BY sh.id", (order_id,)),
        used_parts=db.query(
            "SELECT op.*, p.name, p.sku FROM order_parts op JOIN parts p ON p.id = op.part_id "
            "WHERE op.order_id = ? ORDER BY op.id", (order_id,)),
        statuses=db.query("SELECT * FROM statuses ORDER BY sort_order"),
        manage=logic.can_manage(order, g.user),
    )
    if ctx["manage"]:
        ctx["parts"] = db.query("SELECT * FROM parts WHERE quantity > 0 ORDER BY name")
    if g.user["role"] == "admin":
        ctx["masters"] = db.query(
            "SELECT id, full_name FROM users WHERE role = 'master' AND is_active = 1 ORDER BY full_name")
    return render_template("orders/detail.html", **ctx)


@bp.route("/orders/<int:order_id>/comment", methods=["POST"])
@security.login_required()
def comment(order_id):
    logic.get_order_or_404(order_id)
    try:
        body = v.text(request.form.get("body"), "Комментарий", 1, 1000)
    except v.ValidationError as e:
        flash(str(e), "error")
        return _back(order_id)
    db.execute("INSERT INTO order_comments (order_id, user_id, body) VALUES (?,?,?)",
               (order_id, g.user["id"], body))
    db.commit()
    return _back(order_id)


@bp.route("/orders/<int:order_id>/status", methods=["POST"])
@security.login_required("master", "admin")
def set_status(order_id):
    order = logic.get_order_or_404(order_id, manage=True)
    try:
        changed = logic.change_status(order, request.form.get("status", ""), g.user)
        flash("Статус обновлён" if changed else "Статус не изменился", "ok")
    except v.ValidationError as e:
        flash(str(e), "error")
    return _back(order_id)


@bp.route("/orders/<int:order_id>/parts", methods=["POST"])
@security.login_required("master", "admin")
def add_part(order_id):
    order = logic.get_order_or_404(order_id, manage=True)
    try:
        part_id = v.integer(request.form.get("part_id"), "Запчасть", 1)
        qty = v.integer(request.form.get("quantity"), "Количество", 1, 1000)
        logic.add_part(order, part_id, qty)
        flash("Запчасть добавлена, остаток на складе уменьшен", "ok")
    except v.ValidationError as e:
        flash(str(e), "error")
    return _back(order_id)


@bp.route("/orders/<int:order_id>/parts/<int:op_id>/delete", methods=["POST"])
@security.login_required("master", "admin")
def remove_part(order_id, op_id):
    order = logic.get_order_or_404(order_id, manage=True)
    try:
        logic.remove_part(order, op_id)
        flash("Запчасть возвращена на склад", "ok")
    except v.ValidationError as e:
        flash(str(e), "error")
    return _back(order_id)


@bp.route("/orders/<int:order_id>/labor", methods=["POST"])
@security.login_required("master", "admin")
def set_labor(order_id):
    order = logic.get_order_or_404(order_id, manage=True)
    try:
        cost = v.money(request.form.get("labor_cost"), "Стоимость работ")
        if order["status_code"] == "issued" and g.user["role"] != "admin":
            raise v.ValidationError("Заявка выдана — стоимость изменить нельзя")
    except v.ValidationError as e:
        flash(str(e), "error")
        return _back(order_id)
    db.execute("UPDATE orders SET labor_cost = ?, updated_at = datetime('now') WHERE id = ?",
               (cost, order_id))
    db.commit()
    flash("Стоимость работ сохранена", "ok")
    return _back(order_id)


@bp.route("/orders/<int:order_id>/assign", methods=["POST"])
@security.login_required("admin")
def assign(order_id):
    order = logic.get_order_or_404(order_id)
    raw = request.form.get("master_id", "")
    try:
        master_id = None
        if raw:
            master_id = v.integer(raw, "Мастер", 1)
            if not db.query("SELECT 1 FROM users WHERE id = ? AND role = 'master' AND is_active = 1",
                            (master_id,), one=True):
                raise v.ValidationError("Мастер не найден")
    except v.ValidationError as e:
        flash(str(e), "error")
        return _back(order_id)
    db.execute("UPDATE orders SET master_id = ?, updated_at = datetime('now') WHERE id = ?",
               (master_id, order_id))
    if master_id and order["status_code"] == "accepted":
        db.commit()
        logic.change_status(order, "diagnostics", g.user)
    db.commit()
    flash("Мастер назначен" if master_id else "Назначение снято", "ok")
    return _back(order_id)


# ---------- файлы ----------
@bp.route("/photos/<int:photo_id>")
@security.login_required()
def photo(photo_id):
    row = db.query("SELECT * FROM order_photos WHERE id = ?", (photo_id,), one=True)
    if row is None:
        abort(404)
    logic.get_order_or_404(row["order_id"])  # проверка прав на заявку
    return send_from_directory(current_app.config["UPLOAD_FOLDER"], row["filename"])


@bp.route("/orders/<int:order_id>/receipt.pdf")
@security.login_required()
def receipt(order_id):
    order = logic.get_order_or_404(order_id)
    used = db.query(
        "SELECT op.*, p.name FROM order_parts op JOIN parts p ON p.id = op.part_id "
        "WHERE op.order_id = ? ORDER BY op.id", (order_id,))
    track_url = url_for("public.track", token=order["public_token"], _external=True)
    pdf = build_receipt(order, used, logic.order_total(order), track_url)
    return Response(pdf, mimetype="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="order-{order_id}.pdf"'})
